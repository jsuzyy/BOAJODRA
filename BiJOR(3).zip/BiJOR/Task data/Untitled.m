F = load('B_400.dat');
a = max(F);
b = min(F);

mean(a(:,end))
std(a(:,end))
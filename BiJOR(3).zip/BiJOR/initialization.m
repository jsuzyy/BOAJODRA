function [U,UE,M,Etmin,Ecmin,parameter] = initialization(N)

%Model parameters
UE.N        =   N;                                                      %the number of devices
UE.fd       =   load(['Device data\fd_',num2str(N),'.dat']);            %computational capability of the mobile device
U.H         =   load(['Device data\H_',num2str(N),'.dat']);             %channel gain
U.F         =   load(['Task data\F_',num2str(N),'.dat']);               %total number of the CPU cycles
U.D         =   load(['Task data\D_',num2str(N),'.dat']);               %the size of the input data
U.B         =   load(['Task data\B_',num2str(N),'.dat']);               %the size of the input data
UE.fc       =   2e11;                                                   %the computational capability of the cloud server
UE.f        =   [UE.fc;UE.fd]';                                         %computational capability
UE.pt       =   1.3;                                                    %transmission power
UE.pr       =   0.8;                                                    %reception power
UE.Tmax     =   1;                                                      %maximum time constraints
parameter.W =   20*10^6;                                                %channel bandwidth
parameter.wn=   10^(-13);                                               %background interference power
parameter.alpha =   10^(-27);

%Algorithm parameters
parameter.popsize           =   50;                                             %population size
parameter.maxEvaluations    =   15000;                                          %maximum evulation number
parameter.maxIteration      =   parameter.maxEvaluations/parameter.popsize;
parameter.curIteration      =   0;
parameter.pheromoneIni      =   load(['Task data\pheromoneIni_',num2str(N),'.dat']);
parameter.pheromoneIni      =   1/(UE.N*parameter.pheromoneIni);
parameter.pheromone         =   parameter.pheromoneIni*ones(UE.N,UE.N+1);
parameter.beta              =   2;
parameter.q                 =   0.9;
parameter.phi               =   0.1;
parameter.rho               =   0.1;

Rmax    =   parameter.W*log2(1+UE.pt*U.H/parameter.wn);                                     %the maximum uplink data rate
T_t     =   repmat(U.D,1,UE.N+1)./Rmax + repmat(U.B,1,UE.N+1)./Rmax;                        %the maximum transmission time
fmin    =   repmat(U.F,1,UE.N+1)./(repmat(UE.Tmax,1,UE.N+1)-T_t);                           %the minimum computational resources
M       =   (fmin>=0&fmin<=repmat(UE.f,UE.N,1));                                            %the feasible candidate execution mode

Etmin = (UE.pt.*repmat(U.D,1,UE.N)+UE.pr.*repmat(U.B,1,UE.N))./Rmax(:,2:end)+(UE.pr.*repmat(U.D,1,UE.N)+UE.pt.*repmat(U.B,1,UE.N))./Rmax(:,2:end); %the minimum transmission energy consumption
Ecmin   =   parameter.alpha.*fmin(:,2:end).^2.*repmat(U.F,1,UE.N);                                                                                 %the minimum computation energy consumption
end
